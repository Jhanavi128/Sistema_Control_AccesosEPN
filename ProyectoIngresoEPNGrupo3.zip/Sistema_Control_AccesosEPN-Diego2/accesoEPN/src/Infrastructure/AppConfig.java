package Infrastructure;

public abstract class AppConfig {
    // Paths Storage
    public static final String DATABASE = "jdbc:sqlite:accesoEPN/Storage/DataBase/bd_acceso_epn.sqlite";
    public static final String LOGFILE = "Storage/Logs/AppErrors.log";

    // AppMSGs
    public static final String MSG_DEFAULT_ERROR = "Ups! Error inesperado. Por favor, contacte al administrador del sistema.";
    public static final String MSG_DEFAULT_CLASS = "undefined";
    public static final String MSG_DEFAULT_METHOD = "undefined";

    private AppConfig() {
    }
}
