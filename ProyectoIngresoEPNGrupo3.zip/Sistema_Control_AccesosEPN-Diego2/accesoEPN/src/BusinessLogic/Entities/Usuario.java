package BusinessLogic.Entities;

import BusinessLogic.FactoryBL;
import DataAccess.DAOs.UsuarioDAO;
import DataAccess.DTOs.UsuarioDTO;

public class Usuario {
    protected FactoryBL<UsuarioDTO> factory = new FactoryBL<>(UsuarioDAO.class);
    public UsuarioDTO data = new UsuarioDTO();

}