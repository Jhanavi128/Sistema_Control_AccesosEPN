package DataAccess.DTOs;

public class EstudianteDTO {

    private Integer IdEstudiante;
    private Integer IdUsuario;
    private Integer IdPeriodo;
    private String Nombre;
    private String Apellido;
    private String Cedula;
    private String CodigoUnico;
    private String FechaNacimiento;
    private String Sexo;
    private String Estado;
    private String FechaCreacion;
    private String FechaModifica;

    private transient String carrera;
    private transient String nombrePeriodo;

    private String FotoPath;

    public EstudianteDTO() {
    }

    // 🔹 Constructor base
    public EstudianteDTO(
            Integer idEstudiante,
            Integer idUsuario,
            Integer idPeriodo,
            String nombre,
            String apellido,
            String cedula,
            String codigoUnico,
            String fechaNacimiento,
            String sexo,
            String fotoPath) {
        IdEstudiante = idEstudiante;
        IdUsuario = idUsuario;
        IdPeriodo = idPeriodo;
        Nombre = nombre;
        Apellido = apellido;
        Cedula = cedula;
        CodigoUnico = codigoUnico;
        FechaNacimiento = fechaNacimiento;
        Sexo = sexo;
        FotoPath = fotoPath;
    }

    public EstudianteDTO(
            Integer idEstudiante,
            Integer idUsuario,
            Integer idPeriodo,
            String nombre,
            String apellido,
            String cedula,
            String codigoUnico,
            String fechaNacimiento,
            String sexo,
            String estado,
            String fechaCreacion,
            String fechaModifica,
            String fotoPath) {
        IdEstudiante = idEstudiante;
        IdUsuario = idUsuario;
        IdPeriodo = idPeriodo;
        Nombre = nombre;
        Apellido = apellido;
        Cedula = cedula;
        CodigoUnico = codigoUnico;
        FechaNacimiento = fechaNacimiento;
        Sexo = sexo;
        Estado = estado;
        FechaCreacion = fechaCreacion;
        FechaModifica = fechaModifica;
        FotoPath = fotoPath;
    }

    public Integer getIdEstudiante() {
        return IdEstudiante;
    }

    public void setIdEstudiante(Integer idEstudiante) {
        IdEstudiante = idEstudiante;
    }

    public Integer getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        IdUsuario = idUsuario;
    }

    public Integer getIdPeriodo() {
        return IdPeriodo;
    }

    public void setIdPeriodo(Integer idPeriodo) {
        IdPeriodo = idPeriodo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellido) {
        Apellido = apellido;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String cedula) {
        Cedula = cedula;
    }

    public String getCodigoUnico() {
        return CodigoUnico;
    }

    public void setCodigoUnico(String codigoUnico) {
        CodigoUnico = codigoUnico;
    }

    public String getFechaNacimiento() {
        return FechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        FechaNacimiento = fechaNacimiento;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String sexo) {
        Sexo = sexo;
    }

    public String getFotoPath() {
        return FotoPath;
    }

    public void setFotoPath(String fotoPath) {
        FotoPath = fotoPath;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String estado) {
        Estado = estado;
    }

    public String getFechaCreacion() {
        return FechaCreacion;
    }

    public void setFechaCreacion(String fechaCreacion) {
        FechaCreacion = fechaCreacion;
    }

    public String getFechaModifica() {
        return FechaModifica;
    }

    public void setFechaModifica(String fechaModifica) {
        FechaModifica = fechaModifica;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getNombrePeriodo() {
        return nombrePeriodo;
    }

    public void setNombrePeriodo(String nombrePeriodo) {
        this.nombrePeriodo = nombrePeriodo;
    }

    @Override
    public String toString() {
        return getClass().getName()
                + "\n IdEstudiante     : " + getIdEstudiante()
                + "\n IdUsuario        : " + getIdUsuario()
                + "\n IdPeriodo        : " + getIdPeriodo()
                + "\n Nombre           : " + getNombre()
                + "\n Apellido         : " + getApellido()
                + "\n Cedula           : " + getCedula()
                + "\n CodigoUnico      : " + getCodigoUnico()
                + "\n FechaNacimiento  : " + getFechaNacimiento()
                + "\n Sexo             : " + getSexo()
                + "\n FotoPath         : " + getFotoPath()
                + "\n Estado           : " + getEstado()
                + "\n FechaCreacion    : " + getFechaCreacion()
                + "\n FechaModifica    : " + getFechaModifica();
    }
}
