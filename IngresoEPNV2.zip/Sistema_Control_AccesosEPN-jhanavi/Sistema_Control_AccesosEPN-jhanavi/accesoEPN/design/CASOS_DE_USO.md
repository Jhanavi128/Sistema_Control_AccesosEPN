# Especificación de Casos de Uso (Simplificado)
## Sistema de Control de Accesos EPN

---

## 👥 Actores del Sistema

### 👤 Administrador
Usuario con permisos completos para gestionar estudiantes desde la interfaz desktop.

### 👨‍🎓 Estudiante
Usuario que accede al sistema web para obtener y visualizar su credencial digital con QR.

---

## 📋 Casos de Uso Principales

---

## CU-01: Gestionar Estudiantes

**Actor Principal**: Administrador  
**Objetivo**: Administrar completamente la información de los estudiantes en el sistema.

### Descripción
Permite al administrador realizar todas las operaciones necesarias para mantener actualizada la base de datos de estudiantes, incluyendo la creación, modificación, eliminación, búsqueda y validación de datos.

### Precondiciones
- El administrador ha iniciado la aplicación desktop
- La base de datos está accesible

### Flujo Principal

**1. Crear Estudiante**
1. El administrador selecciona "Nuevo Estudiante"
2. Ingresa datos obligatorios:
   - Código Único (9 dígitos)
   - Nombre y Apellido
   - Cédula de identidad
   - Fecha de nacimiento
   - Sexo (M/F)
   - Periodo académico
   - PIN de acceso (4 dígitos)
3. Opcionalmente carga la foto del estudiante
4. El sistema valida automáticamente:
   - Código único único y de 9 dígitos
   - Cédula no duplicada entre estudiantes activos
   - Todos los campos obligatorios completos
5. Si válido: Crea usuario y estudiante en BD
6. Si inválido: Muestra mensaje de error específico

**2. Editar Estudiante**
1. El administrador busca al estudiante
2. Selecciona "Editar"
3. Modifica los campos necesarios
4. El sistema revalida los datos
5. Actualiza la información en BD

**3. Eliminar Estudiante**
1. El administrador busca al estudiante
2. Selecciona "Eliminar"
3. Confirma la acción
4. El sistema realiza borrado lógico (Estado = 'X')
5. El estudiante ya no aparece en búsquedas activas

**4. Buscar y Filtrar Estudiantes**
1. El administrador ingresa texto en el buscador
2. El sistema busca coincidencias en:
   - Nombre
   - Apellido
   - Código Único
3. Muestra resultados en tabla
4. Administrador puede seleccionar un estudiante para ver detalles

**5. Cargar Foto**
1. Durante creación o edición, clic en "Cargar Foto"
2. Selecciona archivo de imagen (JPG/PNG)
3. Sistema copia imagen a carpeta `Web/Public/`
4. Guarda ruta relativa en BD
5. Foto visible en credencial web del estudiante

**6. Validar Datos**
- Código Único: Exactamente 9 dígitos + único entre activos
- Cédula: No duplicada entre activos
- Campos obligatorios: Todos llenos
- Formatos: Fechas válidas, números correctos

**7. Asignar PIN de Acceso**
- PIN de 4 dígitos
- Se encripta antes de guardar
- Permite al estudiante iniciar sesión web

### Postcondiciones
- **Éxito**: Estudiante creado/actualizado/eliminado en BD
- **Fallo**: Sistema muestra mensaje de error específico y mantiene estado anterior

### Excepciones
- **Error de BD**: "Error al conectar con la base de datos"
- **Datos duplicados**: "El código único/cédula ya existe"
- **Campos vacíos**: "Complete todos los campos obligatorios"
- **Formato incorrecto**: "El código único debe tener 9 dígitos"

---

## CU-02: Acceder a Credencial Digital

**Actor Principal**: Estudiante  
**Objetivo**: Obtener y visualizar la credencial digital con código QR para acceso a la universidad.

### Descripción
Permite al estudiante autenticarse en el sistema web, generar su código QR personalizado y visualizar toda su información académica en formato de credencial digital.

### Precondiciones
- Servidor web activo en puerto 8081
- Estudiante previamente registrado por administrador
- Estado del estudiante = 'A' (activo)

### Flujo Principal

**1. Iniciar Sesión**
1. Estudiante accede a `http://localhost:8081`
2. Sistema muestra formulario de login
3. Estudiante ingresa:
   - Código Único (9 dígitos)
   - PIN de acceso (4 dígitos)
4. Hace clic en "Ingresar"
5. Sistema valida:
   - Código único existe en BD
   - PIN coincide
   - Estado = 'A' (activo)
6. Si válido:
   - Guarda sesión en localStorage
   - Redirige a credencial digital
7. Si inválido:
   - Muestra: "⚠️ Credenciales incorrectas o usuario no activo"
   - Permite reintentar

**2. Visualizar Datos Personales**
El sistema muestra automáticamente:
- Foto del estudiante
- Nombre completo (Nombre + Apellido)
- Código único (grande y destacado)
- Carrera
- Periodo académico actual

**3. Generar y Mostrar Código QR**
1. Sistema toma el código único del estudiante
2. Usa librería QRCode.js para generar QR
3. Tamaño: 180x180 píxeles
4. Muestra el QR centrado en la credencial
5. QR contiene: Código único del estudiante
6. Puede ser escaneado por guardias de seguridad

**4. Ver Carrera y Periodo**
- Carrera: Obtenida de tabla Periodo (JOIN)
- Periodo: Nombre del periodo académico actual
- Formato: "Periodo: 2024-A"

**5. Cerrar Sesión**
1. Estudiante hace clic en "← Volver al Inicio"
2. Sistema limpia localStorage completamente
3. Redirige a página de login
4. Estudiante puede ingresar nuevamente

### Postcondiciones
- **Sesión Iniciada**: Credencial digital visible con QR
- **Sesión Cerrada**: Regreso a login, datos de sesión eliminados

### Flujos Alternativos

**A1: Credenciales Incorrectas**
1. Sistema detecta PIN incorrecto o código no existe
2. Muestra mensaje de error
3. Mantiene al usuario en pantalla de login
4. Permite reintentar

**A2: Usuario Inactivo**
1. Sistema detecta Estado = 'X'
2. Muestra mensaje de usuario no activo
3. Contactar al administrador

**A3: Error de Conexión**
1. Sistema no puede conectar a BD
2. Muestra: "Error de conexión"
3. Permite reintentar

---

## CU-03: Persistir y Consultar Datos

**Actor Principal**: Sistema (Base de Datos SQLite)  
**Objetivo**: Almacenar y recuperar información de forma confiable.

### Descripción
Gestiona todas las operaciones de persistencia y consulta de datos en la base de datos SQLite, garantizando integridad referencial y consistencia.

### Funciones Principales

**1. Almacenar Información de Usuarios y Estudiantes**
- **Tabla Usuario**:
  - Almacena credenciales (código único, PIN)
  - Maneja roles (Estudiante, Administrador, Guardia)
  - Control de estado (A/X)
- **Tabla Estudiante**:
  - Datos personales completos
  - Relación con usuario (FK: IdUsuario)
  - Relación con periodo (FK: IdPeriodo)
  - Ruta de foto

**2. Autenticar Credenciales**
1. Recibe: Código único + PIN
2. Consulta tabla Usuario
3. Verifica coincidencia de contraseña
4. Verifica estado 'A'
5. Retorna: Éxito (con datos) o Fallo

**3. Consultar Datos Académicos**
1. Recibe: ID de usuario
2. Realiza JOIN entre:
   - Estudiante
   - Usuario
   - Periodo
3. Retorna objeto completo con:
   - Datos personales
   - Carrera
   - Nombre del periodo
   - Ruta de foto

### Tablas Involucradas

```
Usuario
├── IdUsuario (PK)
├── CodigoUnico (UNIQUE)
├── Contrasena
├── Rol
├── Estado
└── Timestamps

Estudiante
├── IdEstudiante (PK)
├── IdUsuario (FK → Usuario)
├── IdPeriodo (FK → Periodo)
├── Nombre, Apellido, Cedula
├── CodigoUnico
├── FechaNacimiento, Sexo
├── FotoPath
└── Estado, Timestamps

Periodo
├── IdPeriodo (PK)
├── Nombre (ej: "2024-A")
├── Carrera
└── Estado
```

### Características Técnicas
- **Borrado Lógico**: Los registros no se eliminan físicamente, solo cambian Estado a 'X'
- **Integridad Referencial**: FKs mantienen relaciones consistentes
- **Timestamps**: Rastrea creación y modificación
- **Portabilidad**: Rutas relativas, archivo SQLite único

---

## 🔗 Relaciones Entre Casos de Uso

```
CU-01: Gestionar Estudiantes
    ↓ (usa)
CU-03: Persistir y Consultar Datos
    ↑ (usa)
CU-02: Acceder a Credencial Digital
```

- **CU-01** almacena datos usando **CU-03**
- **CU-02** consulta datos usando **CU-03**
- **CU-03** es utilizado por ambos casos de uso principales

---

## 📊 Matriz de Funcionalidades

| Funcionalidad | CU Principal | Actor |
|---------------|--------------|-------|
| CRUD de estudiantes | CU-01 | Administrador |
| Validación de datos | CU-01 | Sistema |
| Carga de fotos | CU-01 | Administrador |
| Login web | CU-02 | Estudiante |
| Generación de QR | CU-02 | Sistema |
| Visualización de credencial | CU-02 | Estudiante |
| Almacenamiento BD | CU-03 | Sistema |
| Autenticación | CU-03 | Sistema |
| Consultas | CU-03 | Sistema |

---

**Versión**: 2.0 (Simplificada)  
**Fecha**: 29 de Enero de 2026  
**Estado**: Implementado
